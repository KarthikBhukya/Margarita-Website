import React from 'react';
import Navbar  from './Navbar';
import Footer from './Footer';

const Blog = () =>{
    return (
        <div className=''>
            
            <Navbar />
            <section className="whoarewe">
                    {/* <div className='whoarewe-title'> */}
                    <div className=''>
                        <h1>Welcome to Diaz Sifontes's Blog.</h1>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>We Provide live and recently updates and news from various families.</h4>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>Please come again for more information.</h4>
                    </div>
                    
            </section>
            
            <Footer />
        </div>
    );
}

export default Blog;