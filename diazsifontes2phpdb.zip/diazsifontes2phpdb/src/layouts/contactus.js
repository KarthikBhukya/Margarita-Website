import React, { useState } from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';
import Navbar  from './Navbar';
import Footer from './Footer';

const Contactus = () =>{
    
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [yourname,setYourname]=useState('');
    const [youremail,setYouremail]=useState('');
    const [yourmessage,setYourmessage]=useState('');

    const sendMessage = (e)=>{
        e.preventDefault();
        if(yourname===''){
            Swal({
                title:'Error',
                text:"Your Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((yourname.trim()).length <4){
            Swal({
                title:'Name too Small',
                text:"Your Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(youremail===''){
            Swal({
                title:'Error',
                text:"Your Email is Required",
                icon:'warning',
            });
            return false;
        }
        else if((youremail.trim()).length <6){
            Swal({
                title:'Email too Small',
                text:"Your Email is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(yourmessage===''){
            Swal({
                title:'Error',
                text:"Your Message is Required",
                icon:'warning',
            });
            return false;
        }
        else if((yourmessage.trim()).length <10){
            Swal({
                title:'Message too Small',
                text:"Your Message is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting sending contactus form
            let contactusform=new FormData();
            contactusform.append('yourname',yourname);
            contactusform.append('email',youremail);
            contactusform.append('message',yourmessage);

            //sending collected data
            Axios.post(PHP_SERVER_URL+'contactus.php',contactusform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Contact Us',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    // Swal("Success","Your Work has been Saved","success","Close");
    // Swal({
    //     title:'Success',
    //     text:'Your Work has been Saved',
    //     icon:'success',
    //     button:'Close',
    // });
    return (
        <div className=''>
            
            <Navbar />
            <section className="whoarewe">
                <div className="contactus-home">
                    <h3>Send Your Issue Here </h3>
                </div>
                <div className='whoarewe-content'>
                    <form name='contactusform'>
                        <div className='row'>
                            <label>Your Name</label>
                            <input type="text" id="yourname" name="yourname" placeholder='Your Name'
                                    value={yourname} onChange={(e) => setYourname(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Email</label>
                            <input type="email" id="youremail" name="youremail" placeholder='Your Email'
                            value={youremail} onChange={(e) => setYouremail(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Your Message</label>
                            <textarea id="yourmessage" name="yourmessage" placeholder='Enter Your Message Here'
                            value={yourmessage} onChange={(e) => setYourmessage(e.target.value)} required></textarea>
                        </div>

                        <div className='row'>
                            <button className='submit' onClick={sendMessage}>Submit</button>
                        </div>
                    </form>
                    
                </div>
                
            </section>
            
            <Footer />
        </div>
    );
}

export default Contactus;