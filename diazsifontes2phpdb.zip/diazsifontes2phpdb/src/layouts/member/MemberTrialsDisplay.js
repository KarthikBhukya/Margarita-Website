import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const MemberTrialsDisplay = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [trials,setTrials]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadTrials  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'trials.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setTrials(res.data.res);
                    }
                    else{
                        setTrials([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setTrials([]);
                }
            })
            
        }
        loadTrials();

        return () =>{
            active=false
        }
    },[])

    const delTrial= (trial) =>{
        if(!trial){
            Swal({
                title:'Invalid',
                text:"Select Trial",
                icon:'warning',
            });
        }
        //preparing delete trial form
        let deltrialform=new FormData();
        deltrialform.append('id',trial.id);

        if(window.confirm("Delete Trial?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'deltrial.php',deltrialform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Trial</th>
                        <th>Familly</th>
                        <th>Details</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {trials.map((trial) =>(
                        <tr key={trial.id}>
                            <td>{trial.count}</td>
                            <td>{trial.trials}</td>
                            <td>{trial.family}</td>
                            <td>{trial.details}</td>
                            <td>{trial.status}</td>
                            <td>
                                <button className='action-view solve'><i className='fa fa-check-circle'></i> Solve </button>
                                <button className='action-view edit'><i className='fa fa-pencil'></i>  </button>
                                <button className='action-view delete' onClick={(e) => delTrial(trial)}><i className='fa fa-times-circle'></i>  </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default MemberTrialsDisplay;