import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const MemberPropertiesDisplay = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [properties,setProperties]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadProperties  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'properties.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setProperties(res.data.res);
                    }
                    else{
                        setProperties([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setProperties([]);
                }
            })
            
        }
        loadProperties();

        return () =>{
            active=false
        }
    },[])

    const delProperty= (property) =>{
        if(!property){
            Swal({
                title:'Invalid',
                text:"Select Property",
                icon:'warning',
            });
        }
        //preparing delete property form
        let delpropertyform=new FormData();
        delpropertyform.append('id',property.id);

        if(window.confirm("Delete Property?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delproperty.php',delpropertyform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>No</th>
                        <th>Location</th>
                        <th>Family</th>
                        <th>Value</th>
                        <th>Units</th>
                        {/* <th>Units type</th> */}
                        <th>Price(@)</th>
                        <th>Document</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {properties.map((property) =>(
                        <tr key={property.id}> 
                            <td>{property.count}</td>
                            <td>{property.propertyno}</td>
                            <td>{property.location}</td>
                            <td>{property.family}</td>
                            <td>{property.initialvalue}</td>
                            <td>{property.units}</td>
                            {/* <td>{property.unitsdefination}</td> */}
                            <td>{property.sellingperunit}</td>
                            <td><span className='fa fa-file'></span> <a target='_blank' href={PHP_SERVER_URL+ "documents/"+ property.propertyno +"_"+ property.documents}>{property.documents}</a></td>
                            <td>
                                <button className='action-view'><i className='fa fa-sitemap'></i> Expenses </button>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delProperty(property)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default MemberPropertiesDisplay;