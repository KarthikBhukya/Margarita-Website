import React from 'react';
import {Link} from "react-router-dom";
import MemberNavbar from './MemberNavbar';
import MemberSidebar from './MemberSidebar';
import MemberWeeklyChart from './MemberWeeklyChart';
import MemberMonthlyChart from './MemberMonthlyChart';
import MemberTrialsDisplay from './MemberTrialsDisplay';
import MemberProjectsDisplay from './MemberProjectsDisplay';

const MemberDashboard = () =>{
    return (
        <div className=''>
            
            <MemberNavbar />
            <section className="admin">
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <MemberSidebar active='dashboard' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Welcome to Member Dashboard (Your Name)</p>
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <MemberWeeklyChart />
                            </div>
                            <div className='admin-content'>
                                <MemberMonthlyChart />
                            </div>
                        </div>
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Recent Trials</p>
                                <MemberTrialsDisplay />
                                
                            </div>
                        </div>
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Recent Projects</p>
                                <MemberProjectsDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default MemberDashboard;