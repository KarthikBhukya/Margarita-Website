import React,{useState,useEffect} from 'react';
import Axios from 'axios';

const MemberAncestorSelect = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [ancestors,setAncestors]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadAncestors  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'ancestors.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setAncestors(res.data.res);
                    }
                    else{
                        setAncestors([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setAncestors([]);
                }
            })
            
        }
        loadAncestors();

        return () =>{
            active=false
        }
    },[])

    return (
        <>
            <option value="">Choose Ancestor</option>
            {ancestors.map((ancestor) =>(
                <option key={ancestor.id} value={ancestor.id}>{ancestor.ancestorname}</option>
            ))}
        </>
    );
}

export default MemberAncestorSelect;