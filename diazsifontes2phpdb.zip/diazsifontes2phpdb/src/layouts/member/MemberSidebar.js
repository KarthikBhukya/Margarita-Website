import React , {useState} from 'react';
import {Link} from "react-router-dom";

const MemberSidebar = ({active}) =>{
    
    const [dashboard,setDashboard]=useState((active=='dashboard')?'active':'');
    const [trials,setTrials]=useState((active=='trials')?'active':'');
    const [family,setFamily]=useState((active=='family')?'active':'');
    const [projects,setProjects]=useState((active=='projects')?'active':'');
    const [properties,setProperties]=useState((active=='properties')?'active':'');
    const [profile,setProfile]=useState((active=='profile')?'active':'');
    
    return (
        <div className=''>
            <Link className={`sidebar-item ${dashboard}`}  to="/member">Dashboard</Link>
            <Link className={`sidebar-item ${trials}`}  to="/member/trials">Trials</Link>
            <Link className={`sidebar-item ${family}`}  to="/member/family">Family</Link>
            <Link className={`sidebar-item ${projects}`}  to="/member/projects">Projects</Link>
            <Link className={`sidebar-item ${properties}`}  to="/member/properties">Properties</Link>
            <Link className={`sidebar-item ${profile}`}  to="/member/profile">Profile</Link>
            <Link className="sidebar-item"  to="/login">Logout</Link>
        </div>
    );
}

export default MemberSidebar;