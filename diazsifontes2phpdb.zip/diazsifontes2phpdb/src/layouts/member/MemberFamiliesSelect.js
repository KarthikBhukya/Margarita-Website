import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const MemberFamiliesSelect = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [families,setFamilies]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadFamilles  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'families.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setFamilies(res.data.res);
                    }
                    else{
                        setFamilies([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setFamilies([]);
                }
            })
            
        }
        loadFamilles();

        return () =>{
            active=false
        }
    },[])

    return (
        <>
            <option value="">Choose Family</option>
            {families.map((family) =>(
                <option key={family.id} value={family.id}>{family.familyname}</option>
            ))}
        </>
    );
}

export default MemberFamiliesSelect;