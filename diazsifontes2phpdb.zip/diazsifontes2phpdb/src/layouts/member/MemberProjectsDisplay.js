import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const MemberProjectsDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [projects,setProjects]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadProjects  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'projects.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setProjects(res.data.res);
                    }
                    else{
                        setProjects([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setProjects([]);
                }
            })
            
        }
        loadProjects();

        return () =>{
            active=false
        }
    },[])

    const delProject= (project) =>{
        if(!project){
            Swal({
                title:'Invalid',
                text:"Select Project",
                icon:'warning',
            });
        }
        //preparing delete project form
        let delprojectform=new FormData();
        delprojectform.append('id',project.id);

        if(window.confirm("Delete Project?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delproject.php',delprojectform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }


    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Cost</th>
                        <th>Details</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                {/* `projectname`, `family`, `manager`, `location`, `lifetime`, `cost`, `details`, `status */}
                    {projects.map((project) =>(
                        <tr key={project.id}> 
                            <td>{project.count}</td>
                            <td>{project.projectname}</td>
                            <td>{project.location}</td>
                            <td>{project.cost}</td>
                            <td>{project.details}</td>
                            <td>{project.status}</td>
                            <td>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delProject(project)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default MemberProjectsDisplay;