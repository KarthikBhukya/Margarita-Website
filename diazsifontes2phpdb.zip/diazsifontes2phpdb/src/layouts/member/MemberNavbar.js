import React from 'react';
import logo from '../../assets/img/diaz-logo2.png'
import {Link} from "react-router-dom";

const MemberNavbar = () =>{
    let user=localStorage.getItem('userdata');
    if(localStorage.getItem('userdata')){
        user=JSON.parse(localStorage.getItem('userdata')) ;
    }
    else{
        user=false;
    }
    return (
        <div className=''>
            <Link to="/member" className="brand-logo">
                <img src={logo}  alt="Diaz Sifontes Logo" />
            </Link>
            
            <div className="menus">
                <Link className="menus-item" to="/member">Member Dashboard</Link>
                <Link className="menus-item" to="/member/profile">Profile({user['firstname'] +" " +user['lastname']})</Link>
            </div>
            <Link className="menus-item menus-blog" to="/login">Logout</Link>
        </div>
    );
}

export default MemberNavbar;