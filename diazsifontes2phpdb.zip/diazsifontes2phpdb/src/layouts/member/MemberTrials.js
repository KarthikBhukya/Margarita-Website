import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import MemberNavbar from './MemberNavbar';
import MemberSidebar from './MemberSidebar';
import MemberTrialsDisplay from './MemberTrialsDisplay';
import MemberFamiliesSelect from './MemberFamiliesSelect';

const MemberTrials = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [trialname,setTrialname]=useState('');
    const [trialdetails,setTrialDetails]=useState('');
    const [trialstatus,setTrialstatus]=useState('');
    const [family,setFamily]=useState('');

    const submitTrialForm = (e)=>{
        e.preventDefault();
        if(trialname===''){
            Swal({
                title:'Error',
                text:"Trial Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((trialname.trim()).length <4){
            Swal({
                title:'Name too Small',
                text:"Trial Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(family===''){
            Swal({
                title:'Error',
                text:"Family Starting Trial is Required",
                icon:'warning',
            });
            return false;
        }
        else if(trialdetails===''){
            Swal({
                title:'Error',
                text:"Trial Details Information is Required",
                icon:'warning',
            });
            return false;
        }
        else if((trialdetails.trim()).length <10){
            Swal({
                title:'Message too Small',
                text:"Trial Details Information length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(trialstatus===''){
            Swal({
                title:'Error',
                text:"Trial Status is Required",
                icon:'warning',
            });
            return false;
        }
        else if((trialstatus.trim()).length <4){
            Swal({
                title:'Status too Small',
                text:"Trial Status length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting saving trials form
            let trialsform=new FormData();
            trialsform.append('trialname',trialname);
            trialsform.append('trialdetails',trialdetails);
            trialsform.append('family',family);
            trialsform.append('trialstatus',trialstatus);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'savetrials.php',trialsform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <MemberNavbar />
            <section className="admin">
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <MemberSidebar active='trials' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Trials</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Trials</p>
                                <div className=''>
                                    <form name='trialsform'>
                                        <div className='row'>
                                            <label>Trial Name</label>
                                            <input type="text" id="trialname" name="trialname" placeholder='Trial Name'
                                                value={trialname} onChange={(e) => setTrialname(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Family</label>
                                            <select value={family} onChange={(e) => setFamily(e.target.value)} required>
                                                <MemberFamiliesSelect />
                                            </select>
                                        </div>
                                        <div className='row'>
                                            <label>Details</label>
                                            <textarea placeholder='Trial Details'
                                                 value={trialdetails} onChange={(e) => setTrialDetails(e.target.value)} required></textarea>
                                        </div>

                                        <div className='row'>
                                            <label>Status</label>
                                            <input type="text" id="trialstatus" name="trialstatus" placeholder='Trial Status'
                                                value={trialstatus} onChange={(e) => setTrialstatus(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitTrialForm}>Submit Trial</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Trials</p>
                                <MemberTrialsDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default MemberTrials;