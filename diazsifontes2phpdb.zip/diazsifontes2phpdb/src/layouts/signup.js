import React, {useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import Navbar  from './Navbar';
import Footer from './Footer';
import MemberAncestorSelect from './member/MemberAncestorSelect';
import AdminGroupsSelect from './admin/AdminGroupsSelect';

const Signup = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [firstname,setFirstname]=useState('');
    const [youremail,setYouremail]=useState('');
    const [lastname,setLastname]=useState('');
    const [password,setPassword]=useState('');
    const [confirmpassword,setConfirmpassword]=useState('');
    const [loggedas,setLoggedas]=useState('');
    const [ancestor,setAncestor]=useState('');
    const [ancestorrelation,setAncestorrelation]=useState('');
    // console.log(PHP_SERVER_URL);
    const submitSignupform = (e)=>{
        e.preventDefault();
        if(youremail===''){
            Swal({
                title:'Error',
                text:"Your Email is Required",
                icon:'warning',
            });
            return false;
        }
        else if((youremail.trim()).length <6){
            Swal({
                title:'Email too Small',
                text:"Your Email is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(password===''){
            Swal({
                title:'Error',
                text:"Your Password is Required",
                icon:'warning',
            });
            return false;
        }
        else if((password.trim()).length <6){
            Swal({
                title:'Password too Small',
                text:"Your Password is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(confirmpassword!==password){
            Swal({
                title:'Error',
                text:"Confirm Password does not Match Password",
                icon:'warning',
            });
            return false;
        }
        
        else if(firstname===''){
            Swal({
                title:'Error',
                text:"Your First Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((firstname.trim()).length <4){
            Swal({
                title:'First Name too Small',
                text:"Your First Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(lastname===''){
            Swal({
                title:'Error',
                text:"Your Last Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((lastname.trim()).length <4){
            Swal({
                title:'Last Name too Small',
                text:"Your Last Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(loggedas===''){
            Swal({
                title:'Error',
                text:"Choose Logged As",
                icon:'warning',
            });
            return false;
        }

        else if((loggedas==='Member') && (ancestor==="")){
            Swal({
                title:'Error',
                text:"Ancestor is not Selected",
                icon:'warning',
            });
            return false;
        }

        else if((loggedas==='Member') && (ancestorrelation==="")){
            Swal({
                title:'Error',
                text:"Ancestor Relation is not Choosen",
                icon:'warning',
            });
            return false;
        }
        
        else{
            //collecting sending signup form
            let signupform=new FormData();
            signupform.append('email',youremail);
            signupform.append('firstname',firstname);
            signupform.append('lastname',lastname);
            signupform.append('password',password);
            signupform.append('loggedas',loggedas);
            signupform.append('ancestor',ancestor);
            signupform.append('ancestorrelation',ancestorrelation);

            //sending collected data
            Axios.post(PHP_SERVER_URL+'signup.php',signupform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Signed Up',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })

        }
        
    }
    return (
        <div className=''>
            
            <Navbar />
            {/* <section className="page-section"> */}
            <section className="whoarewe">
                <div className="introduction">
                <h3>Create Diaz Sifontes Account</h3>
                </div>
                <div className='whoarewe-content'>
                    <form name='contactusform'>
                        <div className='row'>
                            <label>Email</label>
                            <input type="email" id="youremail" name="youremail" placeholder='Email Address'
                                value={youremail} onChange={(e) => setYouremail(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Password</label>
                            <input type="password" id="password" name="password" placeholder='Password'
                                value={password} onChange={(e) => setPassword(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Confirm Password</label>
                            <input type="password" id="confirmpassword" name="confirmpassword" placeholder='Confirm Password'
                                value={confirmpassword} onChange={(e) => setConfirmpassword(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>First Name</label>
                            <input type="text" id="firstname" name="firstname" placeholder='Your First Name'
                                value={firstname} onChange={(e) => setFirstname(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Last Name</label>
                            <input type="text" id="lastname" name="lastname" placeholder='Your Last Name'
                                value={lastname} onChange={(e) => setLastname(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <label>Register As</label>
                            <div className='radio'>
                                <label className='radio-label'>
                                    <input type="radio" id="loggedmember" name="loggedas" value={loggedas} onChange={(e) => setLoggedas("Member")} />Member
                                </label>
                                <label className='radio-label'>
                                    <input type="radio" id="loggedadmin" name="loggedas" value={loggedas} onChange={(e) => setLoggedas("Admin")} />Admin
                                </label>
                            </div>
                        </div>
                        {loggedas==='Member' &&
                            <>
                                <div className='row'>
                                    <label>Ancestor</label>
                                    <select value={ancestor} onChange={(e) => setAncestor(e.target.value)} required>
                                        <MemberAncestorSelect />
                                    </select>
                                </div>
                                <div className='row'>
                                    <label>Relationship to Ancestor</label>
                                    <select value={ancestorrelation} onChange={(e) => setAncestorrelation(e.target.value)} required>
                                        <AdminGroupsSelect />
                                    </select>
                                </div>
                            </>
                        }
                        <div className='row'>
                            <button className='submit' onClick={submitSignupform}>Go Now</button>
                        </div>
                    </form>
                    
                </div>
            </section>
            
            <Footer />
        </div>
    );
}

export default Signup;