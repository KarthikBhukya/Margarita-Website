import React, {useState} from 'react';
import {Link,Navigate} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import Navbar  from './Navbar';
import Footer from './Footer';

const Logout = () =>{
    const [loggedout,setLoggedout]=useState(false);
    const [redirectto,setRedirectto]=useState('');

    if(localStorage.getItem('userdata')){
        localStorage.removeItem('userdata');
        setLoggedout(true);
        setRedirectto('/login')
    }
    else{
        setLoggedout(true);
        setRedirectto('/login')
    }

    Swal({
        title:'Logged Out',
        text:'Redirecting to Login Page...',
        icon:'success',
    });
    
    
    if(loggedout){
        return <Navigate to={redirectto}/>
    }
    return (
        <div>
           <p>
            Signing Out...!!
           </p>
        </div>
    );
}

export default Logout;