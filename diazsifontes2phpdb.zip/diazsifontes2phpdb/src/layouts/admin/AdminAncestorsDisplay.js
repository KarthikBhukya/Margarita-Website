import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminAncestorsDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [ancestors,setAncestors]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadAncestors  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'ancestors.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setAncestors(res.data.res);
                    }
                    else{
                        setAncestors([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setAncestors([]);
                }
            })
            
        }
        loadAncestors();

        return () =>{
            active=false
        }
    },[])

    const delAncestor= (ancestor) =>{
        if(!ancestor){
            Swal({
                title:'Invalid',
                text:"Select Ancestor",
                icon:'warning',
            });
        }
        //preparing delete ancestor form
        let delancestorform=new FormData();
        delancestorform.append('id',ancestor.id);

        if(window.confirm("Delete Ancestor?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delancestor.php',delancestorform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Country</th>
                        <th>Details</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                {/* `ancestorname`, `country`, `details` */}
                    {ancestors.map((ancestor) =>(
                        <tr key={ancestor.id}> 
                            <td>{ancestor.count}</td>
                            <td>{ancestor.ancestorname}</td>
                            <td>{ancestor.country}</td>
                            <td>{ancestor.details}</td>
                            <td>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delAncestor(ancestor)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminAncestorsDisplay;