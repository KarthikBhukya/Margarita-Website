import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminGroupsDisplay from './AdminGroupsDisplay';

const AdminGroups = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [groupname,setGroupname]=useState('');
    const [groupdetails,setGroupdetails]=useState('');
    const [grouprelatedto,setGrouprelatedto]=useState('');

    const submitGroupForm = (e)=>{
        e.preventDefault();
        if(groupname===''){
            Swal({
                title:'Error',
                text:"Group Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((groupname.trim()).length <3){
            Swal({
                title:'Name too Small',
                text:"Group Name length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(groupdetails===''){
            Swal({
                title:'Error',
                text:"Group Details is Required",
                icon:'warning',
            });
            return false;
        }
        else if((groupdetails.trim()).length <6){
            Swal({
                title:'Details too Small',
                text:"Group Details length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(grouprelatedto===''){
            Swal({
                title:'Error',
                text:"Group Related to is Required",
                icon:'warning',
            });
            return false;
        }
        else if((grouprelatedto.trim()).length <1){
            Swal({
                title:'Group Relation too Small',
                text:"Group Related to length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting saving groups form
            let groupsform=new FormData();
            groupsform.append('groupname',groupname);
            groupsform.append('groupdetails',groupdetails);
            groupsform.append('grouprelatedto',grouprelatedto);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'savegroups.php',groupsform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='groups' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Groups</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Groups</p>
                                <div className=''>
                                    <form name='groupsform'>
                                        <div className='row'>
                                            <label>Group Name</label>
                                            <input type="text" id="groupname" name="groupname" placeholder='Group Name'
                                                value={groupname} onChange={(e) => setGroupname(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Details</label>
                                            <textarea placeholder='Group Details'
                                                value={groupdetails} onChange={(e) => setGroupdetails(e.target.value)} required></textarea>
                                        </div>

                                        <div className='row'>
                                            <label>Related to</label>
                                            <input type="text" id="grouprelatedto" name="grouprelatedto" placeholder='Group Related to'
                                                value={grouprelatedto} onChange={(e) => setGrouprelatedto(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitGroupForm}>Submit Group</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Groups</p>
                                <AdminGroupsDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminGroups;