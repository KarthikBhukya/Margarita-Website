import React,{useState,useEffect} from 'react';
import Axios from 'axios';

const AdminGroupsSelect = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [groups,setGroups]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadGroups  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'groups.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setGroups(res.data.res);
                    }
                    else{
                        setGroups([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setGroups([]);
                }
            })
            
        }
        loadGroups();

        return () =>{
            active=false
        }
    },[])


    return (
        <>
            <option value="">Choose Group</option>
            {groups.map((group) =>(
                <option key={group.id} value={group.id}>{group.groupname}</option>
            ))}
        </>
    );
}

export default AdminGroupsSelect;