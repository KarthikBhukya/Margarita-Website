import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminCountriesDisplay from './AdminCountriesDisplay';

const AdminCountries = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [countryname,setCountryname]=useState('');
    const [countrycode,setCountrycode]=useState('');

    const submitCountryForm = (e)=>{
        e.preventDefault();
        if(countryname===''){
            Swal({
                title:'Error',
                text:"Country Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((countryname.trim()).length <3){
            Swal({
                title:'Name too Small',
                text:"Country Name length is too Small",
                icon:'warning',
            });
            return false;
        }
        
        else if(countrycode===''){
            Swal({
                title:'Error',
                text:"Country Code is Required",
                icon:'warning',
            });
            return false;
        }
        else if((countrycode.trim()).length <1){
            Swal({
                title:'Group Relation too Small',
                text:"Country Code length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting saving countries form
            let countryform=new FormData();
            countryform.append('countryname',countryname);
            countryform.append('countrycode',countrycode);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'savecountries.php',countryform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='countries' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Countries</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Countries</p>
                                <div className=''>
                                    <form name='countriesform'>
                                        <div className='row'>
                                            <label>Country Name</label>
                                            <input type="text" id="countryname" name="countryname" placeholder='Country Name'
                                                value={countryname} onChange={(e) => setCountryname(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Country Code</label>
                                            <input type="number" min={1} id="countrycode" name="countrycode" placeholder='Country Code'
                                                value={countrycode} onChange={(e) => setCountrycode(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitCountryForm}>Submit Country</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Countries</p>
                                <AdminCountriesDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminCountries;