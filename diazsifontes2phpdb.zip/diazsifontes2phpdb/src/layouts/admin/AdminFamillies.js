import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminFamilliesDisplay from './AdminFamilliesDisplay';
import MemberAncestorSelect from '../member/MemberAncestorSelect';

const AdminFamillies = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [ancestor,setAncestor]=useState('');
    const [familylocation,setFamilylocation]=useState('');
    const [family,setFamily]=useState('');

    const submitFamilyForm = (e)=>{
        e.preventDefault();
        if(family===''){
            Swal({
                title:'Error',
                text:"Family Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((family.trim()).length <4){
            Swal({
                title:'Name too Small',
                text:"Family Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(ancestor===''){
            Swal({
                title:'Error',
                text:"Ancestor is Required",
                icon:'warning',
            });
            return false;
        }
        else if(familylocation===''){
            Swal({
                title:'Error',
                text:"Family Location Information is Required",
                icon:'warning',
            });
            return false;
        }
        else if((familylocation.trim()).length <4){
            Swal({
                title:'Location too Small',
                text:"Family Location Information length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting saving family form
            let user=localStorage.getItem('userdata');
            if(localStorage.getItem('userdata')){
                user=JSON.parse(localStorage.getItem('userdata')) ;
            }
            else{
                user=false;
            }
            let familyform=new FormData();
            familyform.append('ancestor',ancestor);
            familyform.append('familylocation',familylocation);
            familyform.append('family',family);
            familyform.append('userid',user['id']);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'savefamily.php',familyform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='family' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Family</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Family</p>
                                <div className=''>
                                    <form name='familyform'>
                                        <div className='row'>
                                            <label>Family Name</label>
                                            <input type="text" id="family" name="family" placeholder='Family Name'
                                                value={family} onChange={(e) => setFamily(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Ancestor</label>
                                            <select value={ancestor} onChange={(e) => setAncestor(e.target.value)} required>
                                                <MemberAncestorSelect />
                                            </select>
                                        </div>

                                        <div className='row'>
                                            <label>Location</label>
                                            <input type="text" id="familylocation" name="familylocation" placeholder='Family Location'
                                                value={familylocation} onChange={(e) => setFamilylocation(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitFamilyForm}>Submit Family</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Famillies</p>
                                <AdminFamilliesDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminFamillies;