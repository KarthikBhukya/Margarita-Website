import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminFamilliesDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [families,setFamilies]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadFamilles  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'families.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setFamilies(res.data.res);
                    }
                    else{
                        setFamilies([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setFamilies([]);
                }
            })
            
        }
        loadFamilles();

        return () =>{
            active=false
        }
    },[])

    const delFamily= (family) =>{
        if(!family){
            Swal({
                title:'Invalid',
                text:"Select Family",
                icon:'warning',
            });
        }
        //preparing delete family form
        let delfamilyform=new FormData();
        delfamilyform.append('id',family.id);

        if(window.confirm("Delete Family?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delfamily.php',delfamilyform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Ancestor</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                {/* `familyname`, `ancestor`, `location`, `user` */}
                    {families.map((family) =>(
                        <tr key={family.id}> 
                            <td>{family.count}</td>
                            <td>{family.familyname}</td>
                            <td>{family.location}</td>
                            <td>{family.ancestor}</td>
                            <td>
                                <button className='action-view solve'><i className='fa fa-plus-circle'></i> </button>
                                <button className='action-view'><i className='fa fa-info-circle'></i> </button>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delFamily(family)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminFamilliesDisplay;