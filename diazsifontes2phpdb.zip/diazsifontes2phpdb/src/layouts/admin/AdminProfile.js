import React from 'react';
import {Link} from "react-router-dom";
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';

const AdminProfile = () =>{
    let user=localStorage.getItem('userdata');
    if(localStorage.getItem('userdata')){
        user=JSON.parse(localStorage.getItem('userdata'));
    }
    else{
        user=false;
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='profile' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Profiles</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Update Personal Information</p>
                                <div className='form-div'>
                                    <form name='profileform'>
                                        <div className='row'>
                                            <label>First Name</label>
                                            <input type="text" id="yourname" name="yourname" placeholder='First Name'
                                                value={user['firstname']} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Last Name</label>
                                            <input type="text" id="yourname" name="yourname" placeholder='Last Name'
                                                value={user['lastname']} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Email</label>
                                            <input type="email" id="yourname" name="yourname" placeholder='Email Address'
                                                value={user['email']} required/>
                                        </div>

                                        
                                        <div className='row'>
                                            <label>Bio</label>
                                            <textarea placeholder='Bio Details' required></textarea>
                                        </div>

                                        <div className='row'>
                                            <button className='submit'>Update Profile</button>
                                        </div>
                                    </form>
                                    
                                </div>

                                <p>Update Profile Photo</p>
                                <div className='form-div'>
                                    <form name='profileform'>
                                        <div className='row'>
                                            <label>Photo</label>
                                            <input type="file" id="yourname" name="yourname" placeholder='Photo' required/>
                                        </div>
                                        <div className='row'>
                                            <button className='submit'>Update Profile Photo</button>
                                        </div>
                                    </form>
                                    
                                </div>

                                <p>Update Password</p>
                                <div className='form-div'>
                                    <form name='profileform'>
                                        <div className='row'>
                                            <label>Password</label>
                                            <input type="password" id="yourname" name="yourname" placeholder='Password' required/>
                                        </div>

                                        <div className='row'>
                                            <label>Confirm Password</label>
                                            <input type="password" id="yourname" name="yourname" placeholder='Confirm Password' required/>
                                        </div>
                                        <div className='row'>
                                            <button className='submit'>Update Password</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Profile Summary</p>
                                    <span>Coming Soon</span>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminProfile;