import React from 'react';
import {Link} from "react-router-dom";
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminMessagesDisplay from './AdminMessagesDisplay';

const AdminMessages = () =>{
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='messages'/>
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Contact US Messages</p>
                        
                        <div className='admin-page'>
                            
                            <div className='admin-content'>
                                <p>Recent Contact US Messages</p>
                                <AdminMessagesDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminMessages;