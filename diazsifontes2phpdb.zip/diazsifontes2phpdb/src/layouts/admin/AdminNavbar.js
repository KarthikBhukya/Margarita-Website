import React, { useState } from 'react';
import logo from '../../assets/img/diaz-logo2.png'

// import logod from '../../../../php_db/documents/diaz4.png'
import {Link} from "react-router-dom";

const AdminNavbar = () =>{
    let user=localStorage.getItem('userdata');
    if(localStorage.getItem('userdata')){
        user=JSON.parse(localStorage.getItem('userdata')) ;
    }
    else{
        user=false;
    }
    return (
        <div className=''>
            <Link to="/admin" className="brand-logo">
                <img src={logo}  alt="Diaz Sifontes Logo" />
                
            </Link>
            
            <div className="menus">
                <Link className="menus-item" to="/admin">Admin Dashboard</Link>
                <Link className="menus-item" to="/admin/profile">Profile({user['firstname'] +" " +user['lastname']})</Link>
                <Link className="menus-item" to="/admin/messages">Messages</Link>
            </div>
            <Link className="menus-item menus-blog" to="/login">Logout</Link>
        </div>
    );
}

export default AdminNavbar;