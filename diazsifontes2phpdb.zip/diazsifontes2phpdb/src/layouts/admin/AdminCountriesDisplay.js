import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminCountriesDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [countries,setCountries]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadCountries  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'countries.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setCountries(res.data.res);
                    }
                    else{
                        setCountries([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setCountries([]);
                }
            })
            
        }
        loadCountries();

        return () =>{
            active=false
        }
    },[])

    const delCountry= (country) =>{
        if(!country){
            Swal({
                title:'Invalid',
                text:"Select Country",
                icon:'warning',
            });
        }
        //preparing delete country form
        let delcountryform=new FormData();
        delcountryform.append('id',country.id);

        if(window.confirm("Delete Country?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delcountry.php',delcountryform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {countries.map((country) =>(
                        <tr key={country.id}> 
                            <td>{country.count}</td>
                            <td>{country.countryname}</td>
                            <td>{country.countrycode}</td>
                            <td>
                                <button className='action-view edit'><i className='fa fa-pencil'></i>  </button>
                                <button className='action-view delete' onClick={(e) => delCountry(country)}><i className='fa fa-times-circle'></i>  </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminCountriesDisplay;