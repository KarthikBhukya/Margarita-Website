import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminCountriesSelect = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [countries,setCountries]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadCountries  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'countries.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setCountries(res.data.res);
                    }
                    else{
                        setCountries([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setCountries([]);
                }
            })
            
        }
        loadCountries();

        return () =>{
            active=false
        }
    },[])

    const delCountry= (country) =>{
        if(!country){
            Swal({
                title:'Invalid',
                text:"Select Country",
                icon:'warning',
            });
        }
        //preparing delete country form
        let delcountryform=new FormData();
        delcountryform.append('id',country.id);

        if(window.confirm("Delete Country?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delcountry.php',delcountryform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <>
            <option value="">Choose Country</option>
            {countries.map((country) =>(
                <option key={country.id} value={country.id}>{country.countryname}</option>
            ))}
        </>
    );
}

export default AdminCountriesSelect;