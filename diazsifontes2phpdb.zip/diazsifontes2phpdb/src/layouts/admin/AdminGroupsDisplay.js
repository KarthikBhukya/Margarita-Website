import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminGroupsDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [groups,setGroups]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadGroups  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'groups.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setGroups(res.data.res);
                    }
                    else{
                        setGroups([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setGroups([]);
                }
            })
            
        }
        loadGroups();

        return () =>{
            active=false
        }
    },[])

    const delGroup= (group) =>{
        if(!group){
            Swal({
                title:'Invalid',
                text:"Select Group",
                icon:'warning',
            });
        }
        //preparing delete group form
        let delgroupform=new FormData();
        delgroupform.append('id',group.id);

        if(window.confirm("Delete Group?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delgroup.php',delgroupform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Details</th>
                        <th>Related To</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                {/* `groupname`, `details`, `inrelationto` */}
                    {groups.map((group) =>(
                        <tr key={group.id}> 
                            <td>{group.count}</td>
                            <td>{group.groupname}</td>
                            <td>{group.details}</td>
                            <td>{group.inrelationto}</td>
                            <td>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delGroup(group)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminGroupsDisplay;