import React from 'react';
import ApexReactCharts from "react-apexcharts";

const AdminMonthlyChart = () =>{
    const series=[
            {
                name: "Trials",
                data: [20, 45, 30, 40, 55, 50, 49, 50, 70, 91, 89, 25]
            },
            {
                name: "Families",
                data: [30, 54, 32, 32, 56, 45, 20, 75, 35, 65, 34, 20]
            },
            {
                name: "Properties",
                data: [35, 26, 76, 26, 45, 24, 87, 45, 56, 78, 32, 65]
            }
            ,
            {
                name: "Projects",
                data: [67, 54, 45, 56, 35, 76, 25, 53, 47, 56, 54, 78]
            }
        ];
    const options={
        chart: {
            id: "monthly-bar",
            height: 300,
          },
          dataLabels:{
            enabled:false
          },
          stroke:{
            curve: 'straight'
          },
          title:{
            text: 'Monthly Data',
            align: 'center'
          },
          grid:{
            row:{
                colors:['#d5f4e6','transparent'],
                opacity:0.4
            }
          },
          xaxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          }
    };
    return (
        <div className=''>
            <ApexReactCharts 
                options={options} 
                series={series}
                type="bar"
                height={245} />
        </div>
    );
}

export default AdminMonthlyChart;