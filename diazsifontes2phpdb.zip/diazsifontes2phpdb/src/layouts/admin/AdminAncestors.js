import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminAncestorsDisplay from './AdminAncestorsDisplay';
import AdminCountriesSelect from './AdminCountriesSelect';

const AdminAncestors = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [ancestorname,setAncestorname]=useState('');
    const [ancestordetails,setAncestordetails]=useState('');
    const [countryname,setCountryname]=useState('');

    const submitAncestorForm = (e)=>{
        e.preventDefault();
        if(ancestorname===''){
            Swal({
                title:'Error',
                text:"Ancestor Name is Required",
                icon:'warning',
            });
            return false;
        }
        
        else if((ancestorname.trim()).length <3){
            Swal({
                title:'Name too Small',
                text:"Ancestor Name length is too Small",
                icon:'warning',
            });
            return false;
        }
        
        else if(countryname===''){
            Swal({
                title:'Error',
                text:"Country Name is Required",
                icon:'warning',
            });
            return false;
        }

        else if((countryname.trim()).length <1){
            Swal({
                title:'Country Name too Small',
                text:"Country Name length is too Small",
                icon:'warning',
            });
            return false;
        }
        
        else if(ancestordetails===''){
            Swal({
                title:'Error',
                text:"Ancestor Details is Required",
                icon:'warning',
            });
            return false;
        }

        else if((ancestordetails.trim()).length <6){
            Swal({
                title:'Details too Small',
                text:"Ancestor Details length is too Small",
                icon:'warning',
            });
            return false;
        }

        else{
            //collecting saving ancestors form
            let ancestorsform=new FormData();
            ancestorsform.append('ancestorname',ancestorname);
            ancestorsform.append('ancestordetails',ancestordetails);
            ancestorsform.append('countryname',countryname);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'saveancestors.php',ancestorsform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='ancestors' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Ancestors</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Ancestors</p>
                                <div className=''>
                                    <form name='ancestorform'>
                                        <div className='row'>
                                            <label>Ancestor Name</label>
                                            <input type="text" id="ancestorname" name="ancestorname" placeholder='Ancestor Name'
                                                value={ancestorname} onChange={(e) => setAncestorname(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Country</label>
                                            <select value={countryname} onChange={(e) => setCountryname(e.target.value)} required>
                                                <AdminCountriesSelect />
                                            </select>
                                        </div>
                                        <div className='row'>
                                            <label>Details</label>
                                            <textarea placeholder='Ancestor Details'
                                                value={ancestordetails} onChange={(e) => setAncestordetails(e.target.value)} required></textarea>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitAncestorForm}>Submit Ancestor</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Ancestor</p>
                                <AdminAncestorsDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminAncestors;