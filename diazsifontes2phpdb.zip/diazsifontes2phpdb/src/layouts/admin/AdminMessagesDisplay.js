import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminMessagesDisplay = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [messages,setMessages]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadMessages  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'messages.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setMessages(res.data.res);
                    }
                    else{
                        setMessages([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setMessages([]);
                }
            })
            
        }
        loadMessages();

        return () =>{
            active=false
        }
    },[])

    const delMessage= (message) =>{
        if(!message){
            Swal({
                title:'Invalid',
                text:"Select Message",
                icon:'warning',
            });
        }
        //preparing delete message form
        let delmessageform=new FormData();
        delmessageform.append('id',message.id);

        if(window.confirm("Delete Message?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delmessage.php',delmessageform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <div className=''>
            <table >
                <thead >
                    <tr>
                        <th>Sn</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Message</th>
                        <th>Response</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                {/* `yourname`, `email`, `message`, `status`, `response` */}
                    {messages.map((message) =>(
                        <tr key={message.id}> 
                            <td>{message.count}</td>
                            <td>{message.yourname}</td>
                            <td>{message.email}</td>
                            <td>{message.message}</td>
                            <td>{message.response}</td>
                            <td>{message.status}</td>
                            <td>
                                <button className='action-view solve'><i className='fa fa-check'></i> </button>
                                <button className='action-view edit'><i className='fa fa-pencil'></i> </button>
                                <button className='action-view delete' onClick={(e) => delMessage(message)}><i className='fa fa-times-circle'></i> </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminMessagesDisplay;