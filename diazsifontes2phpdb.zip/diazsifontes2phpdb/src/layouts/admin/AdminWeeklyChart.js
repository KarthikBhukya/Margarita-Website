import React from 'react';
import ApexReactCharts from "react-apexcharts";

const AdminWeeklyChart = () =>{
    const series=[
            {
                name: "Trials",
                data: [20, 45, 30, 40, 55, 50, 49]
            },
            {
                name: "Families",
                data: [30, 54, 32, 32, 56, 45, 20]
            },
            {
                name: "Properties",
                data: [35, 26, 76, 26, 45, 24, 87]
            }
            ,
            {
                name: "Projects",
                data: [67, 54, 45, 56, 35, 76, 25]
            }
        ];
    const options={
        chart: {
            id: "weekly-bar",
            height: 300,
          },
          dataLabels:{
            enabled:false
          },
          stroke:{
            curve: 'straight'
          },
          title:{
            text: 'Weekly Data',
            align: 'center'
          },
          grid:{
            row:{
                colors:['#fefbd8','transparent'],
                opacity:0.4
            }
          },
          xaxis: {
            categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          }
    };
    return (
        <div className=''>
            <ApexReactCharts 
                options={options} 
                series={series}
                type="bar"
                height={245} />
        </div>
    );
}

export default AdminWeeklyChart;