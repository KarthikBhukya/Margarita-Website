import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminProjectsDisplay from './AdminProjectsDisplay';
import AdminFamiliesSelect from './AdminFamiliesSelect';

const AdminProjects = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [projectname,setProjectname]=useState('');
    const [projectdetails,setProjectdetails]=useState('');
    const [projectstatus,setProjectstatus]=useState('');
    const [projectcost,setProjectcost]=useState('');
    const [projectlocation,setProjectlocation]=useState('');
    const [family,setFamily]=useState('');

    const submitProjectForm = (e)=>{
        e.preventDefault();
        if(projectname===''){
            Swal({
                title:'Error',
                text:"Project Name is Required",
                icon:'warning',
            });
            return false;
        }
        else if((projectname.trim()).length <4){
            Swal({
                title:'Name too Small',
                text:"Project Name is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(projectlocation===''){
            Swal({
                title:'Error',
                text:"Project Location Information is Required",
                icon:'warning',
            });
            return false;
        }
        else if((projectlocation.trim()).length <4){
            Swal({
                title:'Location too Small',
                text:"Project Location Information length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(projectcost===''){
            Swal({
                title:'Error',
                text:"Project Cost Information is Required",
                icon:'warning',
            });
            return false;
        }
        
        else if(isNaN(projectcost.trim())){
            Swal({
                title:'Not a Number',
                text:"Project Cost is not a Number",
                icon:'warning',
            });
            return false;
        }
        else if(family===''){
            Swal({
                title:'Error',
                text:"Family Starting Trial is Required",
                icon:'warning',
            });
            return false;
        }
        else if(projectdetails===''){
            Swal({
                title:'Error',
                text:"Project Details Information is Required",
                icon:'warning',
            });
            return false;
        }
        else if((projectdetails.trim()).length <10){
            Swal({
                title:'Message too Small',
                text:"Project Details Information length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(projectstatus===''){
            Swal({
                title:'Error',
                text:"Project Status is Required",
                icon:'warning',
            });
            return false;
        }
        else if((projectstatus.trim()).length <4){
            Swal({
                title:'Status too Small',
                text:"Project Status length is too Small",
                icon:'warning',
            });
            return false;
        }
        else{
            //collecting saving projects form
            let projectsform=new FormData();
            projectsform.append('projectname',projectname);
            projectsform.append('projectdetails',projectdetails);
            projectsform.append('projectcost',projectcost);
            projectsform.append('projectlocation',projectlocation);
            projectsform.append('family',family);
            projectsform.append('projectstatus',projectstatus);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'saveprojects.php',projectsform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='projects'/>
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Projects</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Projects</p>
                                <div className=''>
                                    <form name='projectsform'>
                                        <div className='row'>
                                            <label>Project Name</label>
                                            <input type="text" id="projectname" name="projectname" placeholder='Project Name'
                                                value={projectname} onChange={(e) => setProjectname(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Project Location</label>
                                            <input type="text" id="projectlocation" name="projectlocation" placeholder='Project Location'
                                                value={projectlocation} onChange={(e) => setProjectlocation(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Project Cost</label>
                                            <input type="number" id="projectcost" name="projectcost" min={0} placeholder='Project Cost'
                                                value={projectcost} onChange={(e) => setProjectcost(e.target.value)} required/>
                                        </div>
                                        <div className='row'>
                                            <label>Family</label>
                                            <select value={family} onChange={(e) => setFamily(e.target.value)} required>
                                                <AdminFamiliesSelect />
                                            </select>
                                        </div>
                                        <div className='row'>
                                            <label>Details</label>
                                            <textarea placeholder='Project Details'
                                                value={projectdetails} onChange={(e) => setProjectdetails(e.target.value)} required></textarea>
                                        </div>

                                        <div className='row'>
                                            <label>Status</label>
                                            <input type="text" id="projectstatus" name="projectstatus" placeholder='Project Status'
                                                value={projectstatus} onChange={(e) => setProjectstatus(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitProjectForm}>Submit Project</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Projects</p>
                                <AdminProjectsDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminProjects;