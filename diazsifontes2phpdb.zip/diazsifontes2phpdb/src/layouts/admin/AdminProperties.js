import React,{useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminPropertiesDisplay from './AdminPropertiesDisplay';
import AdminFamiliesSelect from './AdminFamiliesSelect';

const AdminProperties = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [propertyno,setPropertyno]=useState('');
    const [propertylocation,setPropertylocation]=useState('');
    const [propertydocument,setPropertydocument]=useState('');
    const [intialvalue,setInitialvalue]=useState('');
    const [propertyunits,setPropertyunits]=useState('');
    const [propertysellingperunits,setPropertysellingperunits]=useState('');
    const [unitsdefination,setUnitsDefination]=useState('');
    const [family,setFamily]=useState('');
    

    const submitPropertyForm = (e)=>{
        e.preventDefault();
        if(propertyno===''){
            Swal({
                title:'Error',
                text:"Property Number is Required",
                icon:'warning',
            });
            return false;
        }

        else if(isNaN(propertyno.trim())){
            Swal({
                title:'Not a Number',
                text:"Property Number is not a Number",
                icon:'warning',
            });
            return false;
        }

        else if((propertyno.trim()).length <3){
            Swal({
                title:'Name too Small',
                text:"Property Number length is too Small",
                icon:'warning',
            });
            return false;
        }

        else if(family===''){
            Swal({
                title:'Error',
                text:"Family Starting Trial is Required",
                icon:'warning',
            });
            return false;
        }

        else if(propertylocation===''){
            Swal({
                title:'Error',
                text:"Property Location Information is Required",
                icon:'warning',
            });
            return false;
        }

        else if((propertylocation.trim()).length <4){
            Swal({
                title:'Location too Small',
                text:"Property Location Information length is too Small",
                icon:'warning',
            });
            return false;
        }

        else if(intialvalue===''){
            Swal({
                title:'Error',
                text:"Property Initial Value Information is Required",
                icon:'warning',
            });
            return false;
        }
        
        else if(isNaN(intialvalue.trim())){
            Swal({
                title:'Not a Number',
                text:"Property Initial Value is not a Number",
                icon:'warning',
            });
            return false;
        }


        else if(propertyunits===''){
            Swal({
                title:'Error',
                text:"Property Units Information is Required",
                icon:'warning',
            });
            return false;
        }
        
        else if(isNaN(propertyunits.trim())){
            Swal({
                title:'Not a Number',
                text:"Property Units is not a Number",
                icon:'warning',
            });
            return false;
        }

        else if(unitsdefination===''){
            Swal({
                title:'Error',
                text:"Property Unit Defination Information is Required",
                icon:'warning',
            });
            return false;
        }

        else if((unitsdefination.trim()).length <3){
            Swal({
                title:'Unit Type too Small',
                text:"Property Unit Defination Information length is too Small",
                icon:'warning',
            });
            return false;
        }

        else if(propertysellingperunits===''){
            Swal({
                title:'Error',
                text:"Property Selling Price per Unit Information is Required",
                icon:'warning',
            });
            return false;
        }
        
        else if(isNaN(propertysellingperunits.trim())){
            Swal({
                title:'Not a Number',
                text:"Property Selling Price per Unit is not a Number",
                icon:'warning',
            });
            return false;
        }

        else if(propertydocument===null){
            Swal({
                title:'Error',
                text:"Property Document is Required",
                icon:'warning',
            });
            return false;
        }

        else{
            //collecting saving properties form
            let propertyform=new FormData();
            propertyform.append('propertyno',propertyno);
            propertyform.append('propertyunits',propertyunits);
            propertyform.append('intialvalue',intialvalue);
            propertyform.append('propertylocation',propertylocation);
            propertyform.append('family',family);
            propertyform.append('propertysellingperunits',propertysellingperunits);
            propertyform.append('unitsdefination',unitsdefination);
            propertyform.append('propertydocument',propertydocument);
            // propertyform.append('propertydocument',propertydocument,propertydocument.name);

            //saving collected data
            Axios.post(PHP_SERVER_URL+'saveproperties.php',propertyform,{
                    headers:{
                            'content-type':'multipart/form-data'
                    }
                })
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Saved',
                            text:res.data.success,
                            icon:'success',
                        });
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
        
    }
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='properties' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Admin Properties</p>
                        
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Add/ Update Properties</p>
                                <div className=''>
                                    <form name='propertiesform'>
                                        <div className='row'>
                                            <label>Property No</label>
                                            <input type="text" id="propertyno" name="propertyno" placeholder='Property Number'
                                                value={propertyno} onChange={(e) => setPropertyno(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Family</label>
                                            <select value={family} onChange={(e) => setFamily(e.target.value)} required>
                                                <AdminFamiliesSelect />
                                            </select>
                                        </div>
                                        
                                        <div className='row'>
                                            <label>Location</label>
                                            <input type="text" id="propertylocation" name="propertylocation" placeholder='Property Location'
                                                value={propertylocation} onChange={(e) => setPropertylocation(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Initial Value</label>
                                            <input type="number" id="intialvalue" name="intialvalue" min={0} placeholder='Property Initial Value'
                                                value={intialvalue} onChange={(e) => setInitialvalue(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Units</label>
                                            <input type="number" id="propertyunits" name="propertyunits" min={0} placeholder='Property Units'
                                                value={propertyunits} onChange={(e) => setPropertyunits(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Units Defination</label>
                                            <input type="text" id="unitsdefination" name="unitsdefination" placeholder='Units Defination or type of Unit'
                                            value={unitsdefination} onChange={(e) => setUnitsDefination(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Selling per Unit</label>
                                            <input type="number" id="propertysellingperunits" name="propertysellingperunits" min={0} placeholder='Property Selling prize per Unit'
                                                value={propertysellingperunits} onChange={(e) => setPropertysellingperunits(e.target.value)} required/>
                                        </div>

                                        <div className='row'>
                                            <label>Documents</label>
                                            <input type="file" id="propertydocument" name="propertydocument" placeholder='Property Documents' 
                                               onChange={(e) => setPropertydocument(e.target.files[0])} required/>
                                        </div>

                                        <div className='row'>
                                            <button className='submit' onClick={submitPropertyForm}>Submit Property</button>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            <div className='admin-content'>
                                <p>Recent Properties</p>
                                <AdminPropertiesDisplay />
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminProperties;