import React,{useState,useEffect} from 'react';
import Swal from 'sweetalert';
import Axios from 'axios';

const AdminFamiliesSelect = () =>{

    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;

    const [families,setFamilies]=useState([]);

    useEffect(()=> {
        let active=true;
        const  loadFamilles  = ()  =>{
             Axios({
                method:'GET',
                url:PHP_SERVER_URL+'families.php',
                headers:{
                    'content-type':'application/json'
                }
            })
            .then(res =>{
                if(active){
                    if(res.data.success){
                        setFamilies(res.data.res);
                    }
                    else{
                        setFamilies([]);
                    }
                }
            })
            .catch(err=>{
                if(active){
                    setFamilies([]);
                }
            })
            
        }
        loadFamilles();

        return () =>{
            active=false
        }
    },[])

    const delFamily= (family) =>{
        if(!family){
            Swal({
                title:'Invalid',
                text:"Select Family",
                icon:'warning',
            });
        }
        //preparing delete family form
        let delfamilyform=new FormData();
        delfamilyform.append('id',family.id);

        if(window.confirm("Delete Family?")){
            //deleting prepared data
            Axios.post(PHP_SERVER_URL+'delfamily.php',delfamilyform)
            .then(res => {
                if(res.data.success){
                    Swal({
                        title:'Deleted',
                        text:res.data.success,
                        icon:'success',
                    });
                }
                else{
                    Swal({
                        title:'Failed',
                        text:res.data.error,
                        icon:'info',
                    });
                }
                
            })
            .catch(error=>{
                Swal({
                    title:'Technical Error',
                    text:' '+error,
                    icon:'error',
                });
            })
        }
    }

    return (
        <>
            <option value="">Choose Family</option>
            {families.map((family) =>(
                <option key={family.id} value={family.id}>{family.familyname}</option>
            ))}
        </>
    );
}

export default AdminFamiliesSelect;