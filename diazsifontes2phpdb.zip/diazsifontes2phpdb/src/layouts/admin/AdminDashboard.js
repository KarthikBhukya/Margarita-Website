import React from 'react';
import {Link} from "react-router-dom";
import AdminNavbar from './AdminNavbar';
import AdminSidebar from './AdminSidebar';
import AdminWeeklyChart from './AdminWeeklyChart';
import AdminMonthlyChart from './AdminMonthlyChart';
import AdminTrialsDisplay from './AdminTrialsDisplay';
import AdminProjectsDisplay from './AdminProjectsDisplay';
import AdminMessagesDisplay from './AdminMessagesDisplay';

const AdminDashboard = () =>{
    return (
        <div className=''>
            
            <AdminNavbar />
            <section className="admin">
                {/* <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p> */}
                <div className='admin-contents'>
                    <div className="admin-sidebar">
                        <AdminSidebar active='dashboard' />
                    </div>
                   
                    <div className='admin-pages'>
                        <p style={{color:'black'}}>Welcome to Admin Dashboard (Your Name)</p>
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <AdminWeeklyChart />
                            </div>
                            <div className='admin-content'>
                                <AdminMonthlyChart />
                            </div>
                        </div>
                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Recent Contact Us Messages</p>
                                <AdminMessagesDisplay />
                                
                            </div>

                        </div>

                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Recent Trials</p>
                                <AdminTrialsDisplay />
                                
                            </div>

                        </div>

                        <div className='admin-page'>
                            <div className='admin-content'>
                                <p>Recent Projects</p>
                                <AdminProjectsDisplay />
                                
                            </div>

                        </div>
                        
                    </div>
                    
                </div>
            </section>
        </div>
    );
}

export default AdminDashboard;