import React ,{useState} from 'react';
import {Link} from "react-router-dom";

const AdminSidebar = ({active}) =>{
    
    const [dashboard,setDashboard]=useState((active=='dashboard')?'active':'');
    const [trials,setTrials]=useState((active=='trials')?'active':'');
    const [family,setFamily]=useState((active=='family')?'active':'');
    const [projects,setProjects]=useState((active=='projects')?'active':'');
    const [properties,setProperties]=useState((active=='properties')?'active':'');
    const [messages,setMessages]=useState((active=='messages')?'active':'');
    const [groups,setGroups]=useState((active=='groups')?'active':'');
    const [countries,setCountries]=useState((active=='countries')?'active':'');
    const [ancestors,setAncestors]=useState((active=='ancestors')?'active':'');
    const [profile,setProfile]=useState((active=='profile')?'active':'');
    
    return (
        <div className=''>
            <Link className={`sidebar-item ${dashboard}`}  to="/admin">Dashboard</Link>
            <Link className={`sidebar-item ${trials}`}  to="/admin/trials">Trials</Link>
            <Link className={`sidebar-item ${family}`}  to="/admin/family">Family</Link>
            <Link className={`sidebar-item ${projects}`}  to="/admin/projects">Projects</Link>
            <Link className={`sidebar-item ${properties}`}  to="/admin/properties">Properties</Link>
            <Link className={`sidebar-item ${messages}`}  to="/admin/messages">Messages</Link>
            <Link className={`sidebar-item ${groups}`}  to="/admin/groups">Groups</Link>
            <Link className={`sidebar-item ${countries}`}  to="/admin/countries">Countries</Link>
            <Link className={`sidebar-item ${ancestors}`}  to="/admin/ancestors">Ancestors</Link>
            <Link className={`sidebar-item ${profile}`}  to="/admin/profile">Profile</Link>
            <Link className="sidebar-item"  to="/login">Logout</Link>
        </div>
    );
}

export default AdminSidebar;