import React from 'react';
import logo from '../assets/img/diaz-logo2.png'
import {Link} from "react-router-dom";

const Footer = () =>{
    return (
        <div className=''>
            <div className="footer">
                <a className="footer-item" target="_blank" href="https://goo.gl/maps/Qi955NLJ1AuyeMa28"><span className='fa fa-globe'></span> Address</a>
                <a className="footer-item" href="#"><span className='fa fa-phone'></span> Phone</a>
                <a className="footer-item" href="#"><span className='fa fa-at'></span> Email</a>
                <a className="footer-item" target="_blank" href="https://facebook.com"><span className='fa fa-facebook'></span> Facebook</a>
                <a className="footer-item" href="#"><span className='fa fa-linkedin'></span> Likedln</a>
                <a className="footer-item" href="#"><span className='fa fa-instagram'></span> Instagram</a>
                <a className="footer-item" href="#"><span className='fa fa-pinterest'></span> Pinterest</a>
                <a className="footer-item" href="#"><span className='fa fa-twitter'></span> Twitter</a>
            </div>
        </div>
    );
}

export default Footer;