import React, {useState} from 'react';
import {Link} from "react-router-dom";
import Swal from 'sweetalert';
import Navbar  from './Navbar';

const ForgotPassword = () =>{
    const [email,setEmail]=useState('');

    const submitForgotPasswordform = (e)=>{
        e.preventDefault();
        if(email===''){
            Swal({
                title:'Error',
                text:"Your Email is Required",
                icon:'warning',
            });
            return false;
        }
        else if((email.trim()).length <6){
            Swal({
                title:'Email too Small',
                text:"Your Email is length is too Small",
                icon:'warning',
            });
            return false;
        }
        
        else{
            Swal({
                title:'Success',
                text:"Information is Ready to be Submitted",
                icon:'info',
            });
            return true;
        }
        
    }
    return (
        <div className=''>
            <Navbar />
            <section className="whoarewe">
                <div className="introduction">
                    <h3>Recover your Diaz Sifontes Account</h3>
                </div>
                <div className='whoarewe-content'>
                    <form name='contactusform'>
                        <div className='row'>
                            <label>Email</label>
                            <input type="email" id="yourname" name="yourname" placeholder='Registerd Email Address'
                                value={email} onChange={(e) => setEmail(e.target.value)} required/>
                        </div>
                        <div className='row'></div>
                        
                        <div className='row'>
                            <button className='submit' onClick={submitForgotPasswordform}>Recover</button>
                        </div>
                    </form>
                    
                </div>
            </section>
        </div>
    );
}

export default ForgotPassword;