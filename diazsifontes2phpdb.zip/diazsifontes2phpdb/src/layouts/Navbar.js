import React, { useState } from 'react';
import logo from '../assets/img/diaz-logo2.png'
import {Link} from "react-router-dom";

const Navbar = () =>{
    const [menu, setMenu]=useState(false);
    return (
        <div className=''>
            <Link to="/" className="brand-logo">
                <img src={logo}  alt="Diaz Sifontes Logo" />
            </Link>
            
            <div className="menus">
                <Link className="menus-item" to="/">Home Page</Link>
                <Link className="menus-item" to="/whoarewe">Who Are We</Link>
                <Link className="menus-item" to="/contactus">Contact Us</Link>
                <Link className="menus-item" to="/signup">Signup</Link>
                <Link className="menus-item" to="/login">Login</Link>
                <a className="menus-item menus-blog" target='_blank' rel="noreferrer" href={process.env.REACT_APP_BLOG_URL}>Blog</a>
            </div>

            <div className={`menus-mini ${menu?"active":""}`}>
                <Link className="menus-mini-item"  to="/">Home Page</Link>
                <Link className="menus-mini-item" to="/whoarewe">Who Are We</Link>
                <Link className="menus-mini-item" to="/contactus">Contact Us</Link>
                <a className="menus-mini-item" target='_blank' rel="noreferrer" href={process.env.REACT_APP_BLOG_URL}>Blog</a>
                <Link className="menus-mini-item" to="/signup">Signup</Link>
                <Link className="menus-mini-item" to="/login">Login</Link>
            </div>
            <Link className={`menus-mini-blog ${menu?"active":""}`} onClick={e => (setMenu(!menu))} to="#"><span className='fa fa-bars'></span></Link>
        </div>
    );
}

export default Navbar;