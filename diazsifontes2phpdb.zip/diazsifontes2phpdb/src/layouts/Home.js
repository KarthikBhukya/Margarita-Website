import React from 'react';
import {Link} from "react-router-dom";
import Navbar  from './Navbar';
import Footer from './Footer';

const Home = () =>{
    return (
        <div className=''>
            
            <Navbar />
            <section className="homepage">
                <div className="introduction">
                    <h1>Diaz Sifontes</h1>
                    <h3>Welcome to Diaz Sifontes Family</h3>
                </div>
                <div className='homepage-contents'>
                    <div className='homepage-content'>
                        <span className='fa fa-solid fa-sparkles'></span>
                        <h4>Are You Part of Diaz Sifontes's Family?</h4>
                        <h4>Register Here.</h4>
                        
                            <Link to='/signup' >
                                <button className='btn-register'>Sign Up <span className='fa fa-chevron-right'></span> </button>
                            </Link>
                        
                    </div>
                    <div className='homepage-content'>
                        <span className='fa fa-solid fa-layer-plus'></span>
                        <h4>With your Diaz Sifontes Account?</h4>
                        <h4>Please Login Here.</h4>

                            <Link to='/login' >
                                <button className='btn-register'>Login <span className='fa fa-lock'></span></button>
                            </Link>
                        
                    </div>
                </div>
            </section>

            <section className="whoarewe-home">
                    {/* <div className='whoarewe-title'> */}
                    <div className=''>
                        <h1>Diaz Sifontes Family.</h1>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>Diaz Sifontes is A wealth and large family consisting of more than 275 families.</h4>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>The Family Lives in Margarita Island in South America.</h4>
                        <h4>Basically, Diaz Sifontes contains a large and diverse number of properties and projects.</h4>
                    </div>
                    <div className=''>
                        <h1>Diaz Sifontes Site.</h1>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>This Site is tasked in managing and maintaing all information about each family and what properties or projects they are possesing or working on.</h4>
                        <h4>It Also provides basic infomation to non family members like insights about projects and sale of properties.</h4>
                    </div>
            </section>
            <Footer />
        </div>
    );
}

export default Home;