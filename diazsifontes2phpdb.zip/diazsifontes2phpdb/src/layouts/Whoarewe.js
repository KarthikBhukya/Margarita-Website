import React from 'react';
import Navbar  from './Navbar';
import Footer from './Footer';

const Whoarewe = () =>{
    return (
        <div className=''>
            
            <Navbar />
            <section className="whoarewe">
                    {/* <div className='whoarewe-title'> */}
                    <div className=''>
                        <h1>Diaz Sifontes Family.</h1>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>Diaz Sifontes is A wealth and large family consisting of more than 275 families.</h4>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>The Family Lives in Margarita Island in South America.</h4>
                        <h4>Basically, Diaz Sifontes contains a large and diverse number of properties and projects.</h4>
                    </div>
                    <div className=''>
                        <h1>Diaz Sifontes Site.</h1>
                    </div>
                    <div className='whoarewe-content'>
                        <h4>This Site is tasked in managing and maintaing all information about each family and what properties or projects they are possesing or working on.</h4>
                        <h4>It Also provides basic infomation to non family members like insights about projects and sale of properties.</h4>
                    </div>
            </section>

            
            <Footer />
        </div>
    );
}

export default Whoarewe;