import React, {useState} from 'react';
import {Link,Navigate} from "react-router-dom";
import Swal from 'sweetalert';
import Axios from 'axios';
import Navbar  from './Navbar';
import Footer from './Footer';

const Login = () =>{
    const PHP_SERVER_URL = process.env.REACT_APP_PHP_SERVER_URL;
    const [email,setEmail]=useState('');
    const [password,setPassword]=useState('');
    const [loggedin,setLoggedin]=useState(false);
    const [redirectto,setRedirectto]=useState('');

    const submitLoginform = (e)=>{
        e.preventDefault();
        if(email===''){
            Swal({
                title:'Error',
                text:"Your Email is Required",
                icon:'warning',
            });
            return false;
        }
        else if((email.trim()).length <6){
            Swal({
                title:'Email too Small',
                text:"Your Email is length is too Small",
                icon:'warning',
            });
            return false;
        }
        else if(password===''){
            Swal({
                title:'Error',
                text:"Your Password is Required",
                icon:'warning',
            });
            return false;
        }
        else if((password.trim()).length <6){
            Swal({
                title:'Password too Small',
                text:"Your Password is length is too Small",
                icon:'warning',
            });
            return false;
        }
        
        else{
            //collecting sending login form
            let loginform=new FormData();
            loginform.append('email',email);
            loginform.append('password',password);

            //sending collected data
            Axios.post(PHP_SERVER_URL+'login.php',loginform)
                .then(res => {
                    if(res.data.success){
                        Swal({
                            title:'Logged In',
                            text:res.data.success,
                            icon:'success',
                        });
                        console.log(res.data.userdata)
                        localStorage.setItem('userdata',JSON.stringify(res.data.userdata));
                        setLoggedin(true);
                        if(res.data.loggedas=='Member'){
                            setRedirectto('/member')
                        }
                        else{
                            setRedirectto('/admin')
                        }
                    }
                    else{
                        Swal({
                            title:'Failed',
                            text:res.data.error,
                            icon:'info',
                        });
                    }
                    
                })
                .catch(error=>{
                    Swal({
                        title:'Technical Error',
                        text:' '+error,
                        icon:'error',
                    });
                })
        }
    }

    if(loggedin){
        return <Navigate to={redirectto}/>
    }
    return (
        <div className=''>
            
            <Navbar />
            <section className="whoarewe">
                <div className="introduction">
                    <h3>Login to Your Diaz Sifontes Account</h3>
                </div>
                <div className='whoarewe-content'>
                    <form name='contactusform'>
                        <div className='row'>
                            <label>Email</label>
                            <input type="email" id="yourname" name="yourname" placeholder='Email Address'
                                value={email} onChange={(e) => setEmail(e.target.value)} required/>
                        </div>
                        <div className='row'></div>
                        <div className='row'>
                            <label>Password</label>
                            <input type="password" id="yourname" name="yourname" placeholder='Password'
                                value={password} onChange={(e) => setPassword(e.target.value)} required/>
                        </div>
                        <div className='row'>
                            <button className='submit' onClick={submitLoginform}>Go <span className='fa fa-sign-in'></span></button>
                            {/* <button className='submit' onClick={submitLoginform}>Go Admin</button> */}
                        </div>
                        <div className='row'>
                            Forgot Password? <Link to='/forgot-password'>Recover Here</Link>
                        </div>
                        {/* <div className='row'>
                            Direct Links? 
                            <Link to='/member'>Go Member Direct</Link>
                            <Link to='/admin'>Go Admin Direct</Link>
                        </div> */}
                    </form>
                    
                </div>
            </section>
            
            <Footer />
        </div>
    );
}

export default Login;