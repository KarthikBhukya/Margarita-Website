import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import './assets/css/styles.css';
import Home from './layouts/Home';
import Whoarewe from './layouts/Whoarewe';
import Login from './layouts/login';
import Logout from './layouts/Logout';
import Signup from './layouts/signup';
import Contactus from './layouts/contactus';
import ForgotPassword from './layouts/ForgotPassword';
import Blog from './layouts/Blog';
import AdminDashboard from './layouts/admin/AdminDashboard';
import AdminTrials from './layouts/admin/AdminTrials';
import AdminProjects from './layouts/admin/AdminProjects';
import AdminFamillies from './layouts/admin/AdminFamillies';
import AdminProperties from './layouts/admin/AdminProperties';
import AdminGroups from './layouts/admin/AdminGroups';
import AdminCountries from './layouts/admin/AdminCountries';
import AdminAncestors from './layouts/admin/AdminAncestors';
import AdminProfile from './layouts/admin/AdminProfile';
import AdminMessages from './layouts/admin/AdminMessages';

import MemberDashboard from './layouts/member/MemberDashboard';
import MemberProfile from './layouts/member/MemberProfile';
import MemberProjects from './layouts/member/MemberProjects';
import MemberProperties from './layouts/member/MemberProperties';
import MemberFamillies from './layouts/member/MemberFamillies';
import MemberTrials from './layouts/member/MemberTrials';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
            <Route path='/' element={ <Home />}/>
            <Route path='/whoarewe' element={<Whoarewe />} />
            <Route path='/contactus' element={<Contactus />} />
            <Route path='/signup' element={<Signup />} />
            <Route path='/login' element={<Login />} />
            <Route path='/blog' element={<Blog />} />
            <Route path='/forgot-password' element={<ForgotPassword />} />
            <Route path='/logout' element={<Logout />} />

            <Route path='/admin' element={<AdminDashboard />} />
            <Route path='/admin/trials' element={<AdminTrials />} />
            <Route path='/admin/projects' element={<AdminProjects />} />
            <Route path='/admin/family' element={<AdminFamillies />} />
            <Route path='/admin/groups' element={<AdminGroups />} />
            <Route path='/admin/properties' element={<AdminProperties />} />
            <Route path='/admin/countries' element={<AdminCountries />} />
            <Route path='/admin/ancestors' element={<AdminAncestors />} />
            <Route path='/admin/profile' element={<AdminProfile />} />
            <Route path='/admin/messages' element={<AdminMessages />} />
            <Route path='/admin/logout' element={<Login />} />

            <Route path='/member' element={<MemberDashboard />} />
            <Route path='/member/trials' element={<MemberTrials />} />
            <Route path='/member/projects' element={<MemberProjects />} />
            <Route path='/member/family' element={<MemberFamillies />} />
            <Route path='/member/properties' element={<MemberProperties />} />
            <Route path='/member/profile' element={<MemberProfile />} />

            
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
