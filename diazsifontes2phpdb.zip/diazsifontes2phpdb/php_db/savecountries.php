<?php
//save countries php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//countryname,countrycode,countryname
if(!isset($_POST['countryname']) || $_POST['countryname']==''){
    echo json_encode(["error"=>"Country Name is required"]);
}
else if(!isset($_POST['countrycode']) || $_POST['countrycode']==''){
    echo json_encode(["error"=>"Country Code is required"]);
}
else{
    $countryname=$_POST['countryname'];
    $countrycode=$_POST['countrycode'];

    $signup_stmt='INSERT INTO country(`countryname`, `countrycode`)
    VALUES ("'.$countryname.'","'.$countrycode.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Country Saved Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Save Country."]);
    }
}
?>