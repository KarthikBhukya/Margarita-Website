<?php
//save ancestors php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//ancestorname,ancestordetails,countryname
if(!isset($_POST['ancestorname']) || $_POST['ancestorname']==''){
    echo json_encode(["error"=>"Ancestor Name is required"]);
}
else if(!isset($_POST['ancestordetails']) || $_POST['ancestordetails']==''){
    echo json_encode(["error"=>"Ancestor Details is required"]);
}
else if(!isset($_POST['countryname']) || $_POST['countryname']==''){
    echo json_encode(["error"=>"Ancestor Country is required"]);
}
else{
    $ancestorname=$_POST['ancestorname'];
    $ancestordetails=$_POST['ancestordetails'];
    $countryname=$_POST['countryname'];

    $signup_stmt='INSERT INTO ancestor(`ancestorname`, `country`, `details`)
    VALUES ("'.$ancestorname.'","'.$countryname.'","'.$ancestordetails.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Ancestor Created Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Create Ancestor."]);
    }
}
?>