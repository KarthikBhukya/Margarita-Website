<?php
//save groups php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//groupname,groupdetails,grouprelatedto
if(!isset($_POST['groupname']) || $_POST['groupname']==''){
    echo json_encode(["error"=>"Group Name is required"]);
}
else if(!isset($_POST['groupdetails']) || $_POST['groupdetails']==''){
    echo json_encode(["error"=>"Group Details is required"]);
}
else if(!isset($_POST['grouprelatedto']) || $_POST['grouprelatedto']==''){
    echo json_encode(["error"=>"How Related is Group is required"]);
}
else{
    $groupname=$_POST['groupname'];
    $groupdetails=$_POST['groupdetails'];
    $grouprelatedto=$_POST['grouprelatedto'];

    $signup_stmt='INSERT INTO groups(`groupname`, `details`, `inrelationto`)
    VALUES ("'.$groupname.'","'.$groupdetails.'","'.$grouprelatedto.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Group Saved Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Save Group."]);
    }
}
?>