<?php

error_reporting(~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
$host='localhost';
$username='root';
$password='';
$database='diaz';

?>