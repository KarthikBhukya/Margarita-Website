<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$properties_stmt='SELECT * FROM property ORDER BY id DESC';
$res=array();
if($properties_res=mysqli_query($connection,$properties_stmt)){
    $count=0;
    if(mysqli_num_rows($properties_res)>0){
        while($properties=mysqli_fetch_array($properties_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$properties['id'],
                'propertyno'=>$properties['propertyno'],
                'family'=>$properties['family'],
                'units'=>$properties['units'],
                'location'=>$properties['location'],
                'initialvalue'=>$properties['initialvalue'],
                'sellingperunit'=>$properties['sellingperunit'],
                'documents'=>$properties['documents'],
                'unitsdefination'=>$properties['unitsdefination'],
            );
        }

        echo json_encode(["success"=>"Found Properties","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Properties."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Properties. Seek Technical Support."]);
}
?>