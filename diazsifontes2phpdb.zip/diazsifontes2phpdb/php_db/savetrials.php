<?php
//save trials php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//trialname,trialdetails,family,trialstatus
if(!isset($_POST['trialname']) || $_POST['trialname']==''){
    echo json_encode(["error"=>"Trial is required"]);
}
else if(!isset($_POST['trialdetails']) || $_POST['trialdetails']==''){
    echo json_encode(["error"=>"Trial Details is required"]);
}
else if(!isset($_POST['family']) || $_POST['family']==''){
    echo json_encode(["error"=>"Family is required"]);
}
else if(!isset($_POST['trialstatus']) || $_POST['trialstatus']==''){
    echo json_encode(["error"=>"Trial Status is required"]);
}
else{
    $family=$_POST['family'];
    $trialname=$_POST['trialname'];
    $trialstatus=$_POST['trialstatus'];
    $trialdetails=$_POST['trialdetails'];

    $signup_stmt='INSERT INTO trials(`trials`, `family`, `details`, `status`)
    VALUES ("'.$trialname.'","'.$family.'","'.$trialdetails.'","'.$trialstatus.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Trial Saved Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Save Trial."]);
    }
}
?>