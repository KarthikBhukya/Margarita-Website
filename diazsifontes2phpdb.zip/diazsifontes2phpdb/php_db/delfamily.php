<?php
//del Message php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//id
if(!isset($_POST['id']) || $_POST['id']==''){
    echo json_encode(["error"=>"Family id is required"]);
}
else{
    $id=$_POST['id'];

    $del_stmt='DELETE FROM family where id="'.$id.'"';
    if(mysqli_query($connection,$del_stmt)){
        echo json_encode(["success"=>"Family Deleted."]);  
    }
    else{
        echo json_encode(["error"=>"Family not Deleted."]);
    }
}
?>