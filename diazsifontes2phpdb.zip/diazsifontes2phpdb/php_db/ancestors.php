<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$ancestors_stmt='SELECT * FROM ancestor ORDER BY id DESC';
$res=array();
if($ancestors_res=mysqli_query($connection,$ancestors_stmt)){
    $count=0;
    if(mysqli_num_rows($ancestors_res)>0){
        while($ancestors=mysqli_fetch_array($ancestors_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$ancestors['id'],
                'ancestorname'=>$ancestors['ancestorname'],
                'country'=>$ancestors['country'],
                'details'=>$ancestors['details'],
            );
        }

        echo json_encode(["success"=>"Found Ancestors","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Ancestors."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Ancestors. Seek Technical Support."]);
}
?>