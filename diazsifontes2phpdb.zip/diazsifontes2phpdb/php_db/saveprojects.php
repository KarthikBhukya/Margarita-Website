<?php
//save projects php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//projectname,projectdetails,projectcost,projectlocation,family,projectstatus
if(!isset($_POST['projectname']) || $_POST['projectname']==''){
    echo json_encode(["error"=>"Project Name is required"]);
}
else if(!isset($_POST['projectdetails']) || $_POST['projectdetails']==''){
    echo json_encode(["error"=>"Project Details is required"]);
}
else if(!isset($_POST['projectcost']) || $_POST['projectcost']==''){
    echo json_encode(["error"=>"Project Cost is required"]);
}
else if(!isset($_POST['projectlocation']) || $_POST['projectlocation']==''){
    echo json_encode(["error"=>"Project Location is required"]);
}
else if(!isset($_POST['family']) || $_POST['family']==''){
    echo json_encode(["error"=>"Family is required"]);
}
else if(!isset($_POST['projectstatus']) || $_POST['projectstatus']==''){
    echo json_encode(["error"=>"Project Status is required"]);
}
else{
    $family=$_POST['family'];
    $projectname=$_POST['projectname'];
    $projectstatus=$_POST['projectstatus'];
    $projectdetails=$_POST['projectdetails'];
    $projectcost=$_POST['projectcost'];
    $projectlocation=$_POST['projectlocation'];

    $signup_stmt='INSERT INTO projects(`projectname`, `family`, `location`, `cost`, `details`, `status`)
    VALUES ("'.$projectname.'","'.$family.'","'.$projectlocation.'","'.$projectcost.'","'.$projectdetails.'","'.$projectstatus.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Project Saved Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Save Project."]);
    }
}
?>