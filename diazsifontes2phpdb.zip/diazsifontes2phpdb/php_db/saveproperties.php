<?php
//save properties php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data

//propertyno,propertyunits,intialvalue,propertylocation,family,propertysellingperunits,unitsdefination,propertydocument
if(!isset($_POST['propertyno']) || $_POST['propertyno']==''){
    echo json_encode(["error"=>"Property Name is required"]);
}
else if(!isset($_POST['propertyunits']) || $_POST['propertyunits']==''){
    echo json_encode(["error"=>"Property Details is required"]);
}
else if(!isset($_POST['intialvalue']) || $_POST['intialvalue']==''){
    echo json_encode(["error"=>"Property Cost is required"]);
}
else if(!isset($_POST['propertylocation']) || $_POST['propertylocation']==''){
    echo json_encode(["error"=>"Property Location is required"]);
}
else if(!isset($_POST['family']) || $_POST['family']==''){
    echo json_encode(["error"=>"Family is required"]);
}
else if(!isset($_POST['propertysellingperunits']) || $_POST['propertysellingperunits']==''){
    echo json_encode(["error"=>"Property Status is required"]);
}
else if(!isset($_POST['unitsdefination']) || $_POST['unitsdefination']==''){
    echo json_encode(["error"=>"Units Type is required"]);
}
else if(!$_FILES['propertydocument']){
    echo json_encode(["error"=>"Property Document is required"]);
}
else{
    $family=$_POST['family'];
    $propertyno=$_POST['propertyno'];
    $propertysellingperunits=$_POST['propertysellingperunits'];
    $propertyunits=$_POST['propertyunits'];
    $intialvalue=$_POST['intialvalue'];
    $propertylocation=$_POST['propertylocation'];
    $unitsdefination=$_POST['unitsdefination'];
    $propertydocument=$_POST['propertydocument'];

    $uploadedto='documents/';
    $documentname=$_FILES['propertydocument']['name'];
    $document_temp=$_FILES['propertydocument']['tmp_name'];
    if($_FILES['propertydocument']['error'] >0){
        echo json_encode(["error"=>"Document Was not Uploaded."]);
    }
    else{
        $temp_name=$propertyno.'_'.$documentname;
        $document_uploading=$uploadedto.strtolower($temp_name);

        if(move_uploaded_file($document_temp,$document_uploading)){
            $signup_stmt='INSERT INTO property(`propertyno`, `location`, `units`, `initialvalue`, `sellingperunit`, `documents`, `unitsdefination`, `family`)
            VALUES ("'.$propertyno.'","'.$propertylocation.'","'.$propertyunits.'","'.$intialvalue.'","'.$propertysellingperunits.'","'.$documentname.'","'.$unitsdefination.'","'.$family.'")';
            if(mysqli_query($connection,$signup_stmt)){
                echo json_encode(["success"=>"New Property Saved Successful."]);  
            }
            else{
                echo json_encode(["error"=>"Failed to Save Property."]);
            }
        }
        else{
            echo json_encode(["error"=>"Failed Uploading the Document."]);
        }
    }
}
?>