<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$countries_stmt='SELECT * FROM country ORDER BY id DESC';
$res=array();
if($countries_res=mysqli_query($connection,$countries_stmt)){
    $count=0;
    if(mysqli_num_rows($countries_res)>0){
        while($countries=mysqli_fetch_array($countries_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$countries['id'],
                'countryname'=>$countries['countryname'],
                'countrycode'=>$countries['countrycode'],
            );
        }

        echo json_encode(["success"=>"Found Countries","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Countries."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Countries. Seek Technical Support."]);
}
?>