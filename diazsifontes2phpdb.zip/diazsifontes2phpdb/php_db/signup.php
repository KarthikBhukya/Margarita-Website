<?php
//sign up php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//firstname,lastname,email,password,loggedas,(ancestor,ancestorrelation)
if(!isset($_POST['email']) || $_POST['email']==''){
    echo json_encode(["error"=>"Email is required"]);
}
else if(!isset($_POST['firstname']) || $_POST['firstname']==''){
    echo json_encode(["error"=>"First Name is required"]);
}
else if(!isset($_POST['lastname']) || $_POST['lastname']==''){
    echo json_encode(["error"=>"Last Name is required"]);
}
else if(!isset($_POST['password']) || $_POST['password']==''){
    echo json_encode(["error"=>"Password is required"]);
}
else if(!isset($_POST['loggedas']) || $_POST['loggedas']==''){
    echo json_encode(["error"=>"User type is required"]);
}
else{
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $loggedas=$_POST['loggedas'];
    $ancestor='';
    $ancestorrelation='';
    if($loggedas=='Member'){
        $ancestor=$_POST['ancestor'];
        $ancestorrelation=$_POST['ancestorrelation'];
    }
    else{
        $ancestor='';
        $ancestorrelation='';
    }

    $signup_stmt='INSERT INTO users(`email`, `firstname`, `lastname`, `password`, `loggedas`, `ancestor`, `ancestorrelation`)
    VALUES ("'.$email.'","'.$firstname.'","'.$lastname.'","'.$password.'","'.$loggedas.'","'.$ancestor.'","'.$ancestorrelation.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Account Created Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Signup Failed. Could Not Save Information"]);
    }
}
?>