<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$contactus_stmt='SELECT * FROM contactus ORDER BY id DESC';
$res=array();
if($contactus_res=mysqli_query($connection,$contactus_stmt)){
    $count=0;
    if(mysqli_num_rows($contactus_res)>0){
        while($contactus=mysqli_fetch_array($contactus_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$contactus['id'],
                'yourname'=>$contactus['yourname'],
                'email'=>$contactus['email'],
                'message'=>$contactus['message'],
                'status'=>$contactus['status'],
                'response'=>$contactus['response'],
            );
        }

        echo json_encode(["success"=>"Found Projects","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Projects."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Projects. Seek Technical Support."]);
}
?>