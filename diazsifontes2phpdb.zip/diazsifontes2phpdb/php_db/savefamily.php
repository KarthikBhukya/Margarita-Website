<?php
//save family php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data



//ancestor,familylocation,family,userid
if(!isset($_POST['ancestor']) || $_POST['ancestor']==''){
    echo json_encode(["error"=>"Family Ancestor is required"]);
}
else if(!isset($_POST['familylocation']) || $_POST['familylocation']==''){
    echo json_encode(["error"=>"Family Location is required"]);
}
else if(!isset($_POST['family']) || $_POST['family']==''){
    echo json_encode(["error"=>"Family Name is required"]);
}
else if(!isset($_POST['userid']) || $_POST['userid']==''){
    echo json_encode(["error"=>"Please Login Again."]);
}
else{
    $ancestor=$_POST['ancestor'];
    $familylocation=$_POST['familylocation'];
    $family=$_POST['family'];
    $userid=$_POST['userid'];
    

    $signup_stmt='INSERT INTO family(`familyname`, `ancestor`, `location`, `user`)
    VALUES ("'.$family.'","'.$ancestor.'","'.$familylocation.'","'.$userid.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"New Family Saved Successful."]);  
    }
    else{
        echo json_encode(["error"=>"Failed to Save Family."]);
    }
}
?>