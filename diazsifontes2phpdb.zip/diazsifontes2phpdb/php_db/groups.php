<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$groups_stmt='SELECT * FROM groups ORDER BY id DESC';
$res=array();
if($groups_res=mysqli_query($connection,$groups_stmt)){
    $count=0;
    if(mysqli_num_rows($groups_res)>0){
        while($groups=mysqli_fetch_array($groups_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$groups['id'],
                'groupname'=>$groups['groupname'],
                'details'=>$groups['details'],
                'inrelationto'=>$groups['inrelationto'],
            );
        }

        echo json_encode(["success"=>"Found Groups","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Groups."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Groups. Seek Technical Support."]);
}
?>