<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//email,password
if(!isset($_POST['email']) || $_POST['email']==''){
    echo json_encode(["error"=>"Email is required"]);
}
else if(!isset($_POST['password']) || $_POST['password']==''){
    echo json_encode(["error"=>"Password is required"]);
}
else{
    $email=$_POST['email'];
    $password=$_POST['password'];


    $login_stmt='SELECT * FROM users where `email`="'.$email.'" and `password`="'.$password.'"';
    if($login_res=mysqli_query($connection,$login_stmt)){
        if(mysqli_num_rows($login_res)==1){
            while($user=mysqli_fetch_array($login_res)){
                $response['success']='Login Successful.';
                $response['loggedas']=$user['loggedas'];
                $response['userdata']=array(
                    'id'=>$user['id'],
                    'email'=>$user['email'],
                    'firstname'=>$user['firstname'],
                    'lastname'=>$user['lastname'],
                    'loggedas'=>$user['loggedas'],
                );
                echo json_encode($response);
            }
        }
        else{
            echo json_encode(["error"=>"Username and Password not found."]);
        }
    }
    else{
        echo json_encode(["error"=>"Failed to Login. Seek Technical Support."]);
    }
}
?>