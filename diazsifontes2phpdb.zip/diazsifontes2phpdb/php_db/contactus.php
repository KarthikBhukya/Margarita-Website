<?php
//contactus php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//checking data
//yourname,email,message
if(!isset($_POST['email']) || $_POST['email']==''){
    echo json_encode(["error"=>"Email is required"]);
}
else if(!isset($_POST['yourname']) || $_POST['yourname']==''){
    echo json_encode(["error"=>"First Name is required"]);
}
else if(!isset($_POST['message']) || $_POST['message']==''){
    echo json_encode(["error"=>"Last Name is required"]);
}
else{
    $yourname=$_POST['yourname'];
    $message=$_POST['message'];
    $email=$_POST['email'];

    $signup_stmt='INSERT INTO contactus(`yourname`,`email`, `message`)
    VALUES ("'.$yourname.'","'.$email.'","'.$message.'")';
    if(mysqli_query($connection,$signup_stmt)){
        echo json_encode(["success"=>"Contact Message Sent. Your Will Receive Response Soon."]);  
    }
    else{
        echo json_encode(["error"=>"Message not Sent."]);
    }
}
?>