<?php
//login php code
require('connection.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Max-Age: 2000");
header("Access-Control-Allow-Methods: PUT, POST, GET, DELETE");
header("Access-Control-Allow-Headers: Content-Type,Access-Control_Allow-Headers,Authorization,X-Requested-With");


$connection=mysqli_connect($host,$username,$password,$database);
if(!$connection){
    echo json_encode(["error"=>"Connection to Database Failed"]);
    exit;
}

//loading data

$projects_stmt='SELECT * FROM projects ORDER BY id DESC';
$res=array();
if($projects_res=mysqli_query($connection,$projects_stmt)){
    $count=0;
    if(mysqli_num_rows($projects_res)>0){
        while($projects=mysqli_fetch_array($projects_res)){
            ++$count;
            $res[]=array(
                'count'=>$count,
                'id'=>$projects['id'],
                'projectname'=>$projects['projectname'],
                'family'=>$projects['family'],
                'manager'=>$projects['manager'],
                'location'=>$projects['location'],
                'lifetime'=>$projects['lifetime'],
                'cost'=>$projects['cost'],
                'details'=>$projects['details'],
                'status'=>$projects['status'],
            );
        }

        echo json_encode(["success"=>"Found Projects","res"=>$res]);
    }
    else{
        echo json_encode(["error"=>"No Projects."]);
    }
}
else{
    echo json_encode(["error"=>"Failed Getting Projects. Seek Technical Support."]);
}
?>